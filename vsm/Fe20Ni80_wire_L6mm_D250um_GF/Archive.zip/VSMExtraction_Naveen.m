close all
clear all 
clc

%% Parameters

mu_0 = 1.25663706e-6;
Oe_to_Am = 1e3/(4*pi);
emu_to_Am2 = 1e-3;
M_s = 0.87/mu_0;

d_helix = 250e-6;
L = 6e-3;
A = (d_helix/2)^2*pi;
V = L*A;

%%

Data_ax = dlmread('FeNi_wire-VIRaxial.txt', ',', 1, 0);
H_app_ax = Data_ax(:,8)*Oe_to_Am;
M_ax_ax = (Data_ax(:,10)/1000)*emu_to_Am2/V*(-1);
M_ax_rad = (Data_ax(:,11)/1000)*emu_to_Am2/V*(-1);


 M_s_ax_ax = max(M_ax_ax);
 M_s_ax_rad = max(M_ax_ax);

Data_rad = dlmread('FeNi_wire-VIRradial.txt', ',', 1, 0);
H_app_rad = Data_rad(:,8)*Oe_to_Am;
M_rad_rad = (Data_rad(:,10)/1000)*emu_to_Am2/V*(-1);
M_rad_ax = -(Data_rad(:,11)/1000)*emu_to_Am2/V*(-1);

M_s_rad_rad = max(M_rad_rad);
M_s_rad_ax = max(M_rad_ax);

plot(H_app_ax*mu_0,M_ax_ax,'-*',H_app_ax*mu_0,M_ax_rad,'-*',H_app_rad*mu_0,M_rad_ax,'-*',H_app_rad*mu_0,M_rad_rad,'-*')
grid on
axis tight
xlabel('Applied Field B [T]')
ylabel('Magnetization M [A/m]')
legend('M_{ax,ax}','M_{ax,rad}','M_{rad,ax}','M_{rad,rad}')

Helix_Data_Raw.B_app_ax = Data_ax(:,8);
Helix_Data_Raw.B_app_rad = Data_rad(:,8);
Helix_Data_Raw.M_ax_ax = Data_ax(:,10);
Helix_Data_Raw.M_ax_rad = Data_ax(:,11);
Helix_Data_Raw.M_rad_rad = Data_rad(:,10);
Helix_Data_Raw.M_rad_ax = Data_rad(:,11);

save('Helix_Data_Raw.mat','Helix_Data_Raw')

Helix_Data.B_app_ax = H_app_ax*mu_0;
Helix_Data.B_app_rad = H_app_rad*mu_0;
Helix_Data.M_ax_ax = M_ax_ax;
Helix_Data.M_ax_rad = M_ax_rad;
Helix_Data.M_rad_rad = M_rad_rad;
Helix_Data.M_rad_ax = M_rad_ax;

save('Helix_Data.mat','Helix_Data')

Helix_Data_Normalized.B_app_ax = H_app_ax*mu_0;
Helix_Data_Normalized.B_app_rad = H_app_rad*mu_0;
Helix_Data_Normalized.M_ax_ax = M_ax_ax/M_s_ax_ax;
Helix_Data_Normalized.M_ax_rad = M_ax_rad/M_s_ax_rad;
Helix_Data_Normalized.M_rad_rad = M_rad_rad/M_s_rad_rad;
Helix_Data_Normalized.M_rad_ax = M_rad_ax/M_rad_ax;

save('Helix_Data_Normalized.mat','Helix_Data_Normalized')
